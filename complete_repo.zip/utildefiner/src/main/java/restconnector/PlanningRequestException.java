package restconnector;

public class PlanningRequestException extends Exception {

	private static final long serialVersionUID = 644312513776699251L;

	public PlanningRequestException(String message) {
		super(message);
	}

}
