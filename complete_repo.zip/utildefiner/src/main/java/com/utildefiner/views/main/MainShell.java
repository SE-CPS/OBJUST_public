package com.utildefiner.views.main;

import com.vaadin.flow.component.page.AppShellConfigurator;
import com.vaadin.flow.server.PWA;

@PWA(name = "Utility Definer", shortName = "UtilDefiner")
public class MainShell implements AppShellConfigurator {

}
