import './vaadin-featureflags.ts';

import './index';
